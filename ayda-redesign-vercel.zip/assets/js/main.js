/**
 * AYDA COACHING & SOPHROLOGIE — 2026 INTERACTION & MOTION SYSTEM
 * Modern animations, counters, parallax micro-effects & premium UX
 */

document.addEventListener('DOMContentLoaded', () => {
  initHeader();
  initMobileNav();
  initScrollReveal();
  initCounters();
  initContactForm();
  initActiveLinks();
  initLightbox();
  initTextHighlights();
  initParallaxFloat();
});

/* ==========================================================================
   HEADER SCROLL BEHAVIOR
   ========================================================================== */
function initHeader() {
  const header = document.querySelector('.site-header');
  if (!header) return;

  let lastScrollY = 0;
  let ticking = false;

  const handleScroll = () => {
    const currentScrollY = window.scrollY;

    if (currentScrollY > 30) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }

    lastScrollY = currentScrollY;
    ticking = false;
  };

  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(handleScroll);
      ticking = true;
    }
  }, { passive: true });

  handleScroll(); // run once on load
}

/* ==========================================================================
   MOBILE NAVIGATION DRAWER
   ========================================================================== */
function initMobileNav() {
  const toggleBtn = document.querySelector('.menu-toggle');
  const drawer = document.querySelector('.mobile-drawer');
  const backdrop = document.querySelector('.mobile-backdrop');
  if (!toggleBtn || !drawer || !backdrop) return;

  const openMenu = () => {
    toggleBtn.classList.add('open');
    drawer.classList.add('open');
    backdrop.classList.add('open');
    toggleBtn.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  };

  const closeMenu = () => {
    toggleBtn.classList.remove('open');
    drawer.classList.remove('open');
    backdrop.classList.remove('open');
    toggleBtn.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  };

  toggleBtn.addEventListener('click', () => {
    const isOpen = drawer.classList.contains('open');
    if (isOpen) closeMenu();
    else openMenu();
  });

  backdrop.addEventListener('click', closeMenu);

  // Close when clicking mobile link
  drawer.querySelectorAll('.mobile-nav-link').forEach(link => {
    link.addEventListener('click', closeMenu);
  });

  // ESC key to close
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && drawer.classList.contains('open')) {
      closeMenu();
    }
  });
}

/* ==========================================================================
   SCROLL REVEAL ANIMATIONS — ENHANCED
   ========================================================================== */
function initScrollReveal() {
  const reveals = document.querySelectorAll('.reveal');
  if (!reveals.length) return;

  // Reduced motion check
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    reveals.forEach(el => el.classList.add('active'));
    return;
  }

  // Mark document as JS ready (enables CSS transforms)
  document.documentElement.classList.add('js-ready');

  // Immediately activate hero elements (above the fold)
  document.querySelectorAll('.hero-home .reveal, .page-hero .reveal').forEach(el => {
    // Stagger hero elements for a dramatic entrance
    const delay = el.classList.contains('reveal-delay-2') ? 150 : 0;
    setTimeout(() => el.classList.add('active'), delay);
  });

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
        obs.unobserve(entry.target);
      }
    });
  }, {
    rootMargin: '0px 0px -60px 0px',
    threshold: 0.05
  });

  reveals.forEach(el => {
    if (!el.classList.contains('active')) {
      observer.observe(el);
    }
  });
}

/* ==========================================================================
   COUNTER ANIMATIONS
   ========================================================================== */
function initCounters() {
  const counters = document.querySelectorAll('.stat-number[data-target]');
  if (!counters.length) return;

  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    counters.forEach(el => {
      el.textContent = el.dataset.target;
    });
    return;
  }

  const animateCounter = (el) => {
    const target = parseInt(el.dataset.target, 10);
    const duration = 1800;
    const start = performance.now();
    const startValue = 0;

    const easeOutQuart = (t) => 1 - Math.pow(1 - t, 4);

    const update = (now) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const easedProgress = easeOutQuart(progress);
      const current = Math.round(startValue + (target - startValue) * easedProgress);
      el.textContent = current;
      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        el.textContent = target;
      }
    };

    requestAnimationFrame(update);
  };

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(el => observer.observe(el));
}

/* ==========================================================================
   ACTIVE LINK DETECTION
   ========================================================================== */
function initActiveLinks() {
  const path = window.location.pathname.replace(/\/index\.html$/, '/');
  const navLinks = document.querySelectorAll('.nav-link, .mobile-nav-link');

  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (!href) return;

    link.classList.remove('active');

    if (href === path || 
       (href !== '/' && path.startsWith(href)) || 
       (path === '/' && (href === '/' || href === '/index.html' || href === 'index.html'))) {
      link.classList.add('active');
    }
  });
}

/* ==========================================================================
   CONTACT FORM HANDLING
   ========================================================================== */
function initContactForm() {
  const form = document.getElementById('srfm-form-1711') || document.querySelector('.contact-form');
  if (!form) return;

  const successEl = form.querySelector('.form-feedback.success');
  const errorEl = form.querySelector('.form-feedback.error');
  const submitBtn = form.querySelector('button[type="submit"]');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const nameInput = form.querySelector('input[name*="name"], input[placeholder="Nom"]');
    const emailInput = form.querySelector('input[type="email"]');
    const messageInput = form.querySelector('textarea');

    if (!nameInput?.value.trim() || !emailInput?.value.trim() || !messageInput?.value.trim()) {
      if (errorEl) {
        errorEl.textContent = 'Veuillez remplir tous les champs obligatoires (Nom, Email, Message).';
        errorEl.classList.add('is-visible');
      }
      return;
    }

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Envoi en cours...';
    }

    if (errorEl) errorEl.classList.remove('is-visible');

    setTimeout(() => {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Message envoyé !';
      }
      if (successEl) {
        successEl.textContent = 'Votre message a bien été envoyé. Saliha KADARI vous répondra dans les meilleurs délais.';
        successEl.classList.add('is-visible');
      }
      form.reset();
    }, 800);
  });
}

/* ==========================================================================
   IMAGE LIGHTBOX MODAL
   ========================================================================== */
function initLightbox() {
  const galleryItems = document.querySelectorAll('.gallery-item img, .lightbox-trigger');
  if (!galleryItems.length) return;

  let modal = document.getElementById('lightbox-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'lightbox-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'Image agrandie');
    modal.style.cssText = `
      position: fixed; inset: 0; background: rgba(15, 23, 17, 0.96);
      display: none; align-items: center; justify-content: center;
      z-index: 2000; padding: 2rem; backdrop-filter: blur(8px);
      cursor: zoom-out;
    `;
    modal.innerHTML = `
      <div style="position: relative; max-width: 90vw; max-height: 90vh;">
        <img id="lightbox-img" src="" alt="Agrandissement" style="max-width: 100%; max-height: 85vh; border-radius: 12px; box-shadow: 0 20px 60px rgba(0,0,0,0.6); object-fit: contain;">
        <button id="lightbox-close" aria-label="Fermer" style="position: absolute; top: -16px; right: -16px; background: white; border: none; border-radius: 50%; width: 36px; height: 36px; font-size: 1.2rem; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(0,0,0,0.25);">&times;</button>
      </div>
    `;
    document.body.appendChild(modal);

    const closeLightbox = () => { 
      modal.style.display = 'none';
      document.body.style.overflow = '';
    };
    modal.addEventListener('click', (e) => {
      if (e.target === modal || e.target.id === 'lightbox-close') closeLightbox();
    });
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal.style.display === 'flex') closeLightbox();
    });
  }

  const modalImg = document.getElementById('lightbox-img');

  galleryItems.forEach(img => {
    img.style.cursor = 'zoom-in';
    img.addEventListener('click', (e) => {
      e.preventDefault();
      modalImg.src = img.currentSrc || img.src;
      modal.style.display = 'flex';
      document.body.style.overflow = 'hidden';
    });
  });
}

/* ==========================================================================
   TEXT HIGHLIGHT ANIMATIONS
   ========================================================================== */
function initTextHighlights() {
  const highlights = document.querySelectorAll('.text-highlight');
  if (!highlights.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add('active'), 300);
      }
    });
  }, { threshold: 0.5 });

  highlights.forEach(el => observer.observe(el));
}

/* ==========================================================================
   SUBTLE PARALLAX FLOAT EFFECT
   ========================================================================== */
function initParallaxFloat() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (window.innerWidth < 860) return;

  const heroVisual = document.querySelector('.hero-visual');
  if (!heroVisual) return;

  let rafId;

  const handleMouseMove = (e) => {
    if (rafId) cancelAnimationFrame(rafId);
    rafId = requestAnimationFrame(() => {
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      
      // Subtle tilt based on mouse position
      const tiltX = ((clientY / innerHeight) - 0.5) * 6; // -3 to 3 degrees
      const tiltY = ((clientX / innerWidth) - 0.5) * -6;
      
      heroVisual.style.transform = `perspective(1000px) rotateX(${tiltX}deg) rotateY(${tiltY}deg)`;
    });
  };

  const resetParallax = () => {
    heroVisual.style.transform = '';
  };

  document.addEventListener('mousemove', handleMouseMove, { passive: true });
  document.addEventListener('mouseleave', resetParallax);
  
  // Cleanup to prevent memory leaks
  heroVisual.style.transition = 'transform 0.4s cubic-bezier(0.16, 1, 0.3, 1)';
}
